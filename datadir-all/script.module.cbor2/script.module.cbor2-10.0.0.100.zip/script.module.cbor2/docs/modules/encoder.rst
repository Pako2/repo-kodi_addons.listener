:mod:`cbor2.encoder`
====================

.. automodule:: cbor2.encoder
    :members:
