:mod:`luma.core.interface.serial`
"""""""""""""""""""""""""""""""""
.. automodule:: luma.core.interface.serial
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`luma.core.interface.parallel`
"""""""""""""""""""""""""""""""""""
.. automodule:: luma.core.interface.parallel
    :members:
    :undoc-members:
    :show-inheritance:
