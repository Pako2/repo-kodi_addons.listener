:mod:`luma.core.legacy`
"""""""""""""""""""""""
.. automodule:: luma.core.legacy
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`luma.core.legacy.font`
""""""""""""""""""""""""""""
.. automodule:: luma.core.legacy.font
    :members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: CP437_FONT, SINCLAIR_FONT, LCD_FONT, UKR_FONT, TINY_FONT,SEG7_FONT
