Installation
------------
There is no need to directly install this package - it should get installed automatically
as a dependency when installing a specific display driver. See the instructions in the
relevant documentation
