luma.core
=========

.. image:: https://github.com/rm-hull/luma.core/workflows/luma.core/badge.svg?branch=master
   :target: https://github.com/rm-hull/luma.core/actions?workflow=luma.core

.. image:: https://coveralls.io/repos/github/rm-hull/luma.core/badge.svg?branch=master
   :target: https://coveralls.io/github/rm-hull/luma.core?branch=master

.. image:: https://img.shields.io/maintenance/yes/2021.svg?maxAge=2592000

.. image:: https://img.shields.io/pypi/pyversions/luma.core.svg
    :target: https://pypi.org/project/luma.core

.. image:: https://img.shields.io/pypi/v/luma.core.svg
   :target: https://pypi.org/project/luma.core

.. image:: https://img.shields.io/pypi/dm/luma.core
   :target: https://pypi.python.org/project/luma.core

.. toctree::
   :maxdepth: 2

   intro
   install
   api-documentation

.. include:: ../CONTRIBUTING.rst
.. include:: ../CHANGES.rst
.. include:: ../LICENSE.rst

