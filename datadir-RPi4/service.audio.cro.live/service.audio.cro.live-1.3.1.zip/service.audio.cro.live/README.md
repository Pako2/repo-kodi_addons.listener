# service.audio.cro.live
Doplněk pro Kodi - služba pro generování playlistu a EPG stanic Českého rozhlasu.

Podporu hledejte ve fóru [XBMC-Kodi.cz](https://www.xbmc-kodi.cz/index.php) v příspěvku [ČRo Live](https://www.xbmc-kodi.cz/prispevek-cro-live).
